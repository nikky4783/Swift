import UIKit

var str = "Hello, playground"
let a = 10
var name = "nikhil"
print("My name is \(name)")
print("Hello, world!")
// prints "Hello, world!

// Swift combines powerful type of interference and pattern matching with a modern, lightweiight syntax.
